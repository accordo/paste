A2Z is compressed of A2.bin, please use R4_xlz.bin to load it.
